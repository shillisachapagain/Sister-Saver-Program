/*
 * Shillisa, Stephan, Morgan Yeh
 * 2023/12/17
 * Class to represent a tile on 2048 board
 */

package finalproject.sms;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

public class Tile {
   //attributes
   private int xPos;
   private int yPos;
   private int value; //number that is displayed on tile
   private int startNum; //the starting number of the chain of tiles (eg 2,3, etc)
   private boolean combinable; //whether the tile is allowed to be combined
   
   /**
    * Primary Constructor, allows creation of Tile with default attributes
    */
   public Tile() {
       xPos = 0;
       yPos = 0;
       value = 0;
       startNum = 0;
       combinable = false;
   }
   
   /**
    * Secondary Constructor, allows creation of Tile with Attributes set
    * @param xPos - x position of Tile
    * @param yPos - y position of Tile
    * @param value - number on the Tile
    * @param startNum - the base number
    */
   public Tile(int xPos, int yPos, int value, int startNum) {
       this();
       this.xPos = xPos;
       this.yPos = yPos; 
       this.value = value;
       this.startNum = startNum;
       combinable = true; //Tile is allowed to be combined with another tile      
   }

   /**
    * getter for xPos
    * @return - x position of tile
    */
    public int getXPos() {
        return xPos;
    }

    /**
     * setter for xPos
     * @param xPos - new x position of the Tile
     */
    public void setXPos(int xPos) {
        this.xPos = xPos;
    }

    /**
     * getter for yPos
     * @return - y position of the Tile
     */
    public int getYPos() {
        return yPos;
    }

    /**
     * setter for yPos
     * @param yPos - new y position of Tile
     */
    public void setYPos(int yPos) {
        this.yPos = yPos;
    }

    /**
     * getter for value;
     * @return - numerical value of the Tile
     */
    public int getValue() {
        return value;
    }

    /**
     * setter for value
     * @param value - new value of Tile
     */
    public void setValue(int value) {
        this.value = value;
    }

    /**
     * getter for startNum
     * @return - starting number associated with the Tile
     */
    public int getStartNum() {
        return startNum;
    }

    /**
     * setter for startNum
     * @param startNum - new starting number for the Tile
     */
    public void setStartNum(int startNum) {
        this.startNum = startNum;
    }
    
    /**
     * getter for combinable
     * @return - whether the tile can be combined with another tile
     */
    public boolean isCombinable() {
        return combinable;
    }
    
    /**
     * setter for combinable
     * @param combinable - the next combinable state of the Tile
     */
    public void setCombinable(boolean combinable) {
        this.combinable = combinable;
    }
   
    /**
     * draws the Tile;
     * @param g2d - Graphics2D object to draw with
     */
    public void draw(Graphics2D g2d){
        int size = 0; //size of font to display on Tile
        //locations to display text
        int xLoc = 0;
        int yLoc = 0;
        
        Color c = Color.LIGHT_GRAY; //default colour is Gray
        
        //change the colour for every tile
        if(value == startNum * Math.pow(2, 1)) {
            c = Color.GREEN; 
        } else if(value == startNum * Math.pow(2, 2)) {
            c = Color.BLUE;
        } else if(value == startNum * Math.pow(2, 3)) {
            c = Color.MAGENTA;
        } else if (value == startNum * Math.pow(2, 4) || value == startNum * Math.pow(2, 5)) {
            c = Color.RED;
        } else if (value >= startNum * Math.pow(2, 6)) {
            c = Color.ORANGE;
        }
        
        //adjust size of text depending on value of Tile
        if (value < 10) {
            size = 50;
            xLoc = xPos+30;
            yLoc = yPos+58;
            
        } else if (value >= 10 && value < 100) {
            size = 50;
            xLoc = xPos+18;
            yLoc = yPos+57;
            
        } else if (value >= 100 && value < 1000) {
            size = 40;
            xLoc = xPos+13;
            yLoc = yPos+56;
            
        } else if (value >= 1000 && value < 10000) { 
            size = 32;
            xLoc = xPos+11;
            yLoc = yPos+53;
        } else {//for numbers above 10000
            size = 28;
            xLoc = xPos+7;
            yLoc = yPos+51;
        }

        //draw the tile and number
        g2d.setColor(c);
        g2d.fillRect(xPos, yPos, 84, 84);
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Serif", Font.PLAIN, size));
        g2d.drawString(value + "", xLoc, yLoc);
    }
    
    /**
     * moves the Tile to the space on the left
     */
    public void moveLeft() {
        xPos -= 100;
        
    }
    
    /**
     * moves the Tile to the space on the right
     */
    public void moveRight() {
        xPos += 100;
    }
    
    /**
     * moves the Tile upwards to next space
     */
    public void moveUp(){
        yPos -= 100;
    }
    
    /**
     * moves the Tile downwards to next space
     */
    public void moveDown() {
        yPos += 100;
        
    }
    
    public Tile clone() {
        Tile copy = new Tile(xPos, yPos, value, startNum);
        
        return copy;
    }
    
    /**
     * equals method for Tile
     * @param other - the other Tile to compare with
     * @return - whether the Tiles are equal
     */
    public boolean equals(Tile other) {
        //Tiles are same if same value and startNum
        return (this.value == other.value) && (this.startNum == other.startNum);
    }
    
    /**
     * toString method for Tile
     * @return - String representation of Tile
     */
    public String toString() {
        return "TILE\nxPos: " + xPos + "\nyPos: " + yPos + "\nValue: " + value + "\nStart Number: " + startNum + "\nCombinable? " + combinable;
    }

   }

    