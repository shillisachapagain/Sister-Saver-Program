/*
 * Shillisa, Morgan, Stephan
 * 12/15/2023
 * Class Represents a Gameboard
*/

package finalproject.sms;

public class Board {
    
    //attributes
    private Tile[][] gameBoard;
    
    /**
     * Primary constructor for default Board
     */
    public Board() {
        gameBoard = null;
    }
    
    /**
     * Secondary constructor for a certain Board
     * @param gameBoard - the board
     */
    public Board(Tile[][] gameBoard) {
        this(); //constructor chaining
        this.gameBoard = gameBoard;
    }
    
    /**
     * Getter method for certain Tile
     * @param r - the row
     * @param c - the column
     * @return - the Tile
     */
    public Tile getTile(int r, int c) {
        return gameBoard[r][c];
    }
    
    /**
     * Setter method for certain Tile
     * @param r - the row
     * @param c - the column
     * @param t - the Tile
     */
    public void setTile(int r, int c, Tile t) {
        this.gameBoard[r][c] = t;
    }
    
    /**
     * Method to generate a Tile
     * @param startNum - the number of the smallest tile
     */
    public void generate(int startNum) {
        boolean end = false;
        //coordinates of the space in top left corner of board [0][0]
        int topLeftX = 213;
        int topLeftY = 213;
        int distance = 100; //how far two tiles are apart
        
        while (!end) {
            //generate 2 random numbers from 0-3
            int rRow = (int)(Math.random()*4);
            int rColumn = (int)(Math.random()*4);

            //check if the space at the coordinates generated is null (empty)
            if(gameBoard[rRow][rColumn] == null) {
            //create a new starting Tile and store it in the coordinates on the board
            Tile generatedTile = new Tile(topLeftX + distance * rColumn, topLeftY + distance * rRow, startNum, startNum); //value of new Tile is 2

            //add the new tile to the array
            gameBoard[rRow][rColumn] = generatedTile;
            
            //end the loop
            end = true;
            }
        }
    }

    /**
     * Method to duplicate Board
     * @return - the cloned Board
     */
    public Board clone() {
        return new Board(gameBoard);
    }
    
    /**
     * Method that determines whether two Boards are equal
     * @param other - the other Board
     * @return - equal or not
     */
    public boolean equals(Board other) {
        //two boards are equal if all the tiles are the same and in same position
        
        //go through all the tiles in the array
        for (int row = 0; row < 4; row++) {
            for (int column = 0; column < 4; column++) {
                
                //get the tiles from both Boards
                Tile t = gameBoard[row][column];
                Tile otherT = other.gameBoard[row][column];
                
                //check if both are not null
                if (t != null && otherT != null) {
                    //check if the two tiles are different numbers
                    if (t.getValue() != otherT.getValue()) {
                        return false; //tiles are different, thus not equal
                    }
                    
                } else {
                   return false; //one tile is null while the other isn't
                }
            }
        }
        
        return true; //all tiles are the same
    }
    
    /**
     * toString Method
     * @return - string representation of the board
     */
    @Override
    public String toString() {
        return "Board{" + "gameBoard=" + gameBoard + '}';
    }
}