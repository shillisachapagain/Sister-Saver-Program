/*
 * Shillisa, Morgan, Stephan
 * 12/15/2023
 * Class to represent a Player
*/
package finalproject.sms;

public class Player {
    
    //attributes
    private String name;
    private int score;
    
    /**
     * Primary constructor for default Player
     */
    public Player() {
        name = "Anonymous";
        score = 0;
    }

    /**
     * Secondary constructor for Player with name, score, time
     * @param name - their name
     * @param score - their highest number
     */
    public Player(String name, int score) {
        this(); //constructor chaining
        this.name = name;
        this.score = score;
    }

    /**
     * Getter method for name
     * @return - the name
     */
    public String getName() {
        return name;
    }

    /**
     * Getter method for score
     * @return - the score
     */
    public int getScore() {
        return score;
    }

    /**
     * Setter method for the name
     * @param name - the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Setter method for the score
     * @param score - the new score
     */
    public void setScore(int score) {
        this.score = score;
    }

    /**
     * Duplicates current Player
     * @return - the cloned Player
     */
    public Player clone() {
        return new Player(name, score);
    }
    
    /**
     * Method to determine whether two Players are the same
     * @param other - the other Player
     * @return - equal or not
     */
    public boolean equals(Player other) {
        return this.name.equals(other.name) && this.score == other.score;
    }
    
    //toString method
    @Override
    public String toString() {
        return name + "\t\t" + score + "\n";
    }
}
