/*
 * Shillisa, Stephan, Morgan
 * 2024/01/16
 * Class to represent an object that will play sound when key is pressed
 */
package finalproject.sms;

import java.io.BufferedInputStream;
import java.io.InputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JOptionPane;

public class GameSound {

    void playSound() {
        try { //trycatch for the music
            InputStream musicPath = MainMusic.class.getResourceAsStream("soundEffect.wav"); //new music file

            //add buffer for mark/reset support
            InputStream bufferedIn = new BufferedInputStream(musicPath);

            //determine whether music exists or not
            if (musicPath != null) {
                //get the audio clip and start it
                AudioInputStream audioInput = AudioSystem.getAudioInputStream(bufferedIn);
                Clip clip = AudioSystem.getClip();
                clip.open(audioInput);
                clip.start();
               
            } else { //if the file doesn't exist
                JOptionPane.showMessageDialog(null, "Music file not found");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Music file not found" + ex);
        }
    }
}