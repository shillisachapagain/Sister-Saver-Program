/**
 * Shillisa, Morgan, Stephan
 * 2023-1-8
 * Drawing surface for the game screen
 */
package finalproject.sms;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class BoardDrawingSurface extends JPanel implements KeyListener, MouseListener, Runnable {

    private Leaderboard secondWindow;
    private MainMenu firstWindow;
    private GameBoardScreen fifthWindow;

    private Thread animator;
    private final int DELAY = 25;

    private Image boardImg;
    private Image starImg;
    private Image diceImg;
    private Image borderImg;

    private Tile[][] tiles;
    private Board b;

    public static int score;
    public static String playerName;

    private boolean gameWon = false; //whether the game has been won
    private boolean gameOver = false; //whether user has failed the game

    final private int start; //the number the user starts with
    final private int target; //the number the user wants to reach

    private boolean write; //whether the program should write to file
    private String gameState = "Playing";

    /**
     * Primary constructor
     * @param r - the main menu screen
     * @param gbs - the gameboard screen to draw on 
     */
    public BoardDrawingSurface(MainMenu r, GameBoardScreen gbs) {
        firstWindow = r;
        fifthWindow = gbs;
        //set write to true and reset score
        write = true;
        score = 0;
        
        setBackground(Color.DARK_GRAY); //set background Color

        //get the start and target numbers from the mode selection screen
        start = ModeSelection.getStartNum();
        target = ModeSelection.getTargetNum();

        //create 4x4 array of Tiles
        tiles = new Tile[4][4];

        //instantiate a new Board class
        b = new Board(tiles);

        //attach mouse listenerr to panel and give focus
        this.addMouseListener(this);
        this.addKeyListener(this);
        this.setFocusable(true);
        this.requestFocus();

        //get Blank Board image
        boardImg = getImgIcon("blankBoard.png").getImage();
        //get Star image
        starImg = getImgIcon("stars.png").getImage();
        //get Dice image
        diceImg = getImgIcon("dice.png").getImage();
        //get Border image
        borderImg = getImgIcon("border.png").getImage();

        //generate 2 tiles on random spaces on the board
        b.generate(start);
        b.generate(start);
    }

    /**
     * Secondary constructor
     * @param fourthWindow - the mode selection screen
     */
    BoardDrawingSurface(ModeSelection fourthWindow) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * Method to load and create an image
     *
     * @param imgName - the image name
     * @return - the ImageIcon
     */
    public ImageIcon getImgIcon(String imgName) {
        // Load image from JAR resource
        URL imageURL = getClass().getResource(imgName);

        // load Board image
        return new ImageIcon(imageURL);
    }

    /**
     * Method to set the Player's name
     *
     * @param name - the new name
     */
    public static void setPlayerName(String name) {
        if (name.equals("")) {
            playerName = "Unnamed";
        } else {
            playerName = name;
        }
    }

    /**
     * method to check if the user has won the game
     *
     * @return - whether user has reached the 2048 tile
     */
    public boolean isGameWon() {
        //go through all the tiles on the Board
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                //check if the space is occupied by a tile
                if (b.getTile(row, col) != null) {

                    //check if the tile has value of the target number
                    if (b.getTile(row, col).getValue() == target) {
                        return true; //game has been won, return true
                    }
                }
            }
        }

        return false; //target tile does not exist on game board, user has not won
    }

    /**
     * Method to check if the user has lost the game
     *
     * @return - whether user can make any more inputs to change the board
     */
    public boolean isGameOver() {
        //check all Tiles on board
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                //check if there are empty spaces on board
                if (b.getTile(row, col) == null) {
                    //game is not over as there are still spaces for Tiles to move
                    return false;
                }
            }
        }

        //go through all tiles to see if any adjacent tiles are the same
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                //get the Tile at the current location and the tiles adjacent to it
                Tile t = b.getTile(row, col);

                //compare with tile below if Tile is not in last row
                if (row != 3) {
                    //get the tile below
                    Tile adjDown = b.getTile(row + 1, col);

                    //check if tile below is the same as current tile
                    if (t.equals(adjDown)) {
                        //game is not over as tiles can still be combined
                        return false;
                    }
                }

                //compare with tile to the right if current is not in last column
                if (col != 3) {
                    //get the tile to the right
                    Tile adjRight = b.getTile(row, col + 1);

                    //check if tile to the right is the same as current tile
                    if (t.equals(adjRight)) {
                        //game is not over as tiles can still be combined
                        return false;
                    }
                }

            }
        }
        //board fails all checks for whether game can be continued
        return true; //game is over, user cannot make any more inputs
    }

    /**
     * Does the actual drawing
     *
     * @param g - the Graphics object to draw with
     */
    private void doDrawing(Graphics g) {
        //the Graphics2D class is the class that handles all the drawing
        //must be casted from older Graphics class in order to have access to some newer methods
        Graphics2D g2d;
        g2d = (Graphics2D) g;

        String mode;

        //check which mode the user is playing
        if (start == 2) { //start = 2 is classic mode
            mode = "Classic Mode";
        } else { //anything else is custom mode
            mode = "Custom Mode: " + start;
        }

        if (gameState.equals("Playing")) {
            drawBoard(g2d, mode);
        } else if (gameState.equals("Won")) { //they won the game
            drawBoard(g2d, mode);
            drawGameOutcome(g2d, "You Win!", Color.blue);

        } else { //they lost the game
            drawBoard(g2d, mode);
            drawGameOutcome(g2d, "Game Over!", Color.red);

        }
    }

    /**
     * Method that draws the main board of the game screen
     *
     * @param g2d - the Graphics2D drawing tool
     * @param mode - the current game state
     */
    public void drawBoard(Graphics2D g2d, String mode) {
        //draw the Border image
        g2d.drawImage(borderImg, 70, 430, this);
        //draw the Background of Stars
        g2d.drawImage(starImg, 0, 0, this);
        g2d.drawImage(starImg, 400, 300, this);
        //draw the Board image
        g2d.drawImage(boardImg, 200, 200, this);
        //draw the Dice image
        g2d.drawImage(diceImg, 500, -30, this);

        //Displays rectangle for the back button
        g2d.setColor(Color.GRAY);
        g2d.fillRect(550, 650, 150, 70);

        //displays the back button
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Serif", Font.PLAIN, 40));
        g2d.drawString("QUIT", 572, 698);

        //Displays title for game screen
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("SansSerif Bold", Font.PLAIN, 50));
        g2d.drawString("2048+ " + mode, 30, 58);

        //Displays the player label
        g2d.setFont(new Font("Serif", Font.PLAIN, 30));
        g2d.drawString("Player: " + playerName, 30, 120);

        //Displays the time label
        g2d.setFont(new Font("Serif", Font.PLAIN, 30));
        g2d.drawString("Score: " + score, 30, 180);

        //draw the board
        //go through all the Tiles in the array
        for (int row = 0; row <= 3; row++) {
            for (int column = 0; column <= 3; column++) {

                //check if the current tile is not null
                if (b.getTile(row, column) != null) {
                    //get and draw the tile at the current position
                    Tile toDraw = b.getTile(row, column);
                    toDraw.draw(g2d);

                }
            }
        }
    }

    /**
     * Method to draw the game outcome
     *
     * @param g2d - the Graphics2D drawer
     * @param text - the text to show
     * @param c - the color with the text
     */
    public void drawGameOutcome(Graphics2D g2d, String text, Color c) {
        g2d.setColor(c);
        g2d.setFont(new Font("Serif", Font.PLAIN, 100));
        g2d.drawString(text, 160, 300);
        g2d.setColor(Color.white);
        g2d.fillRect(80, 350, 620, 200);
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.fillRect(90, 360, 600, 180);
        g2d.setColor(Color.white);
        g2d.setFont(new Font("Serif", Font.PLAIN, 30));
        g2d.drawString("Player: " + playerName, 100, 420);
        g2d.drawString("Score: " + score, 100, 500);
        g2d.fillRect(280, 580, 240, 70);
        g2d.setColor(Color.GRAY);
        g2d.fillRect(290, 590, 220, 50);
        g2d.setColor(Color.white);
        g2d.drawString("Leaderboard", 320, 625);
    }

    /**
     * Starts the Thread
     */
    @Override
    public void addNotify() {
        super.addNotify();
        animator = new Thread(this);
        animator.start();
    }

    /**
     * Runs the program
     */
    public void run() {

        long beforeTime, timeDiff, waitTime;
        //get current time
        beforeTime = System.currentTimeMillis();

        while (true) {

            //check if user has won the game
            gameWon = isGameWon();
            //check if user has lost the game
            gameOver = isGameOver();

            if (gameWon) { //check game states
                gameState = "Won";
            } else if (gameOver) {
                gameState = "Over";
            }

            //redraw the screen
            repaint();

            //calculate amount of time elapsed since last call
            timeDiff = System.currentTimeMillis() - beforeTime;

            //calculate amount of time to wait until nect call
            waitTime = DELAY - timeDiff;

            //make sure wait time is always at least 2 ms
            if (waitTime < 0) {
                waitTime = 2;
            }

            //try catch to wait
            try {
                Thread.sleep(waitTime);
            } catch (InterruptedException e) {
                System.out.println(e);
            }

            //get the new current time
            beforeTime = System.currentTimeMillis();
        }
    }

    /**
     * Overrides paintComponent in JPanel class so that we can do our own custom
     * painting
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);//does the necessary work to prepare the panel for drawing
        doDrawing(g); //invoke our custom drawing method
    }

    /**
     * make all the tiles in the board combinable
     */
    public void makeCombinable() {
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {

                //ensure the tile is not empty
                if (b.getTile(row, col) != null) {
                    //make the tile combinable
                    b.getTile(row, col).setCombinable(true);
                }

            }
        }
    }

    /**
     * method to handle key interaction
     *
     * @param e - KeyEvent to handle
     */
    public void keyPressed(KeyEvent e) {

        int numMoves = 1; //number of times tiles have been moved - set to 1
        boolean moveMade = false; //boolean to check if tiles were moved

        //make all the tiles combinable
        makeCombinable();

        //check which arrow key is pressed and ensure game is still playing
        if (e.getKeyCode() == KeyEvent.VK_LEFT && gameState.equals("Playing")) {

            while (numMoves > 0) {
                //assume no movements have been made
                numMoves = 0;

                //go through all Tiles in array
                for (int row = 0; row <= 3; row++) {
                    for (int column = 1; column <= 3; column++) { //don't need to check leftmost column
                        //check that Tile at current index is not null
                        if (b.getTile(row, column) != null) {

                            //get the Tile at the current index
                            Tile t = b.getTile(row, column);

                            //check if space to the left is empty
                            if (b.getTile(row, column - 1) == null) {
                                //move tile left
                                t.moveLeft();

                                //reassign tile to new index and make original index null
                                b.setTile(row, column - 1, t);
                                b.setTile(row, column, null);

                                //increase movements by 1 and make boolean true
                                numMoves++;
                                moveMade = true;
                            } else if (b.getTile(row, column - 1).equals(t) && b.getTile(row, column - 1).isCombinable() == true && b.getTile(row, column).isCombinable() == true) { //check if tile beside is the same and both are combinable
                                //move tile left
                                t.moveLeft();

                                //get value of current Tile and combine the two tiles
                                int value = t.getValue();
                                Tile combined = new Tile(t.getXPos(), t.getYPos(), value * 2, start);

                                //make original index null and set new tile to new space on board
                                b.setTile(row, column - 1, combined);
                                b.setTile(row, column, null);

                                //set the combined tile to be not combinable anymore
                                b.getTile(row, column - 1).setCombinable(false);

                                //increase score by value of combined tile
                                score += combined.getValue();

                                //increase movements by 1 and make boolean true
                                numMoves++;
                                moveMade = true;
                            }

                        }
                    }
                }

            }

        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT && gameState.equals("Playing")) {
            while (numMoves > 0) {
                //assume no movements have been made
                numMoves = 0;

                //go through all Tiles in array
                for (int row = 0; row <= 3; row++) {
                    for (int column = 2; column >= 0; column--) { //don't need to check rightmost column
                        //check that Tile at current index is not null
                        if (b.getTile(row, column) != null) {

                            //get the Tile at the current index
                            Tile t = b.getTile(row, column);

                            //check if space to the right is empty
                            if (b.getTile(row, column + 1) == null) {
                                //move tile to the right
                                t.moveRight();
                                //reassign tile to new index and make original index null
                                b.setTile(row, column + 1, t);
                                b.setTile(row, column, null);

                                //increase movements by 1 and make boolean true
                                numMoves++;
                                moveMade = true;
                            } else if (b.getTile(row, column + 1).equals(t) && b.getTile(row, column + 1).isCombinable() == true && b.getTile(row, column).isCombinable() == true) { //check if tile beside is the same
                                //move Tile to the right
                                t.moveRight();
                                //get value of current Tile and combine the two tiles
                                int value = t.getValue();
                                Tile combined = new Tile(t.getXPos(), t.getYPos(), value * 2, start);

                                //make original index null and set new tile to new space on board
                                b.setTile(row, column + 1, combined);
                                b.setTile(row, column, null);

                                //set the combined tile to be not combinable anymore
                                b.getTile(row, column + 1).setCombinable(false);

                                //increase score by value of combined tile
                                score += combined.getValue();

                                //increase movements by 1 and make boolean true
                                numMoves++;
                                moveMade = true;
                            }

                        }
                    }
                }

            }

        } else if (e.getKeyCode() == KeyEvent.VK_UP && gameState.equals("Playing")) {
            while (numMoves > 0) {
                //assume no movements have been made
                numMoves = 0;

                //go through all Tiles in array
                for (int row = 1; row <= 3; row++) { //don't need to check top most row
                    for (int column = 0; column <= 3; column++) {
                        //check that Tile at current index is not null
                        if (b.getTile(row, column) != null) {

                            //get the Tile at the current index
                            Tile t = b.getTile(row, column);

                            //check if space above is empty
                            if (b.getTile(row - 1, column) == null) {
                                //move tile up
                                t.moveUp();
                                //reassign tile to new index and make original index null
                                b.setTile(row - 1, column, t);
                                b.setTile(row, column, null);

                                //increase movements by 1 and make boolean true
                                numMoves++;
                                moveMade = true;
                            } else if (b.getTile(row - 1, column).equals(t) && b.getTile(row - 1, column).isCombinable() == true && b.getTile(row, column).isCombinable() == true) { //check if tile above is the same
                                //move Tile up
                                t.moveUp();
                                //get value of current Tile and combine the two tiles
                                int value = t.getValue();
                                Tile combined = new Tile(t.getXPos(), t.getYPos(), value * 2, start);

                                //make original index null and set new tile to new space on board
                                b.setTile(row - 1, column, combined);
                                b.setTile(row, column, null);

                                //set the combined tile to be not combinable anymore
                                b.getTile(row - 1, column).setCombinable(false);

                                //increase score by value of combined tile
                                score += combined.getValue();

                                //increase movements by 1 and make boolean true
                                numMoves++;
                                moveMade = true;
                            }

                        }
                    }
                }

            }

        } else if (e.getKeyCode() == KeyEvent.VK_DOWN && gameState.equals("Playing")) {
            while (numMoves > 0) {
                //assume no movements have been made
                numMoves = 0;

                //go through all Tiles in array
                for (int row = 2; row >= 0; row--) { //don't need to check bottom most row
                    for (int column = 0; column <= 3; column++) {
                        //check that Tile at current index is not null
                        if (b.getTile(row, column) != null) {

                            //get the Tile at the current index
                            Tile t = b.getTile(row, column);

                            //check if space below is empty
                            if (b.getTile(row + 1, column) == null) {
                                //move tile down
                                t.moveDown();
                                //reassign tile to new index and make original index null
                                b.setTile(row + 1, column, t);
                                b.setTile(row, column, null);

                                //increase movements by 1 and make boolean true
                                numMoves++;
                                moveMade = true;
                            } else if (b.getTile(row + 1, column).equals(t) && b.getTile(row + 1, column).isCombinable() == true && b.getTile(row, column).isCombinable() == true) { //check if tile below is the same
                                //move Tile down
                                t.moveDown();
                                //get value of current Tile and combine the two tiles
                                int value = t.getValue();
                                Tile combined = new Tile(t.getXPos(), t.getYPos(), value * 2, start);

                                //make original index null and set new tile to new space on board
                                b.setTile(row + 1, column, combined);
                                b.setTile(row, column, null);

                                //set the combined tile to be not combinable anymore
                                b.getTile(row + 1, column).setCombinable(false);

                                //increase score by value of combined tile
                                score += combined.getValue();

                                //increase movements by 1 and make boolean true
                                numMoves++;
                                moveMade = true;
                            }

                        }
                    }
                }

            }

        }
        //check if arrow keys are pressed
        if((e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_DOWN) && gameState.equals("Playing") && moveMade) {
            GameSound musicObject = new GameSound(); 
            musicObject.playSound();
        }
        
        //genereate a new tile ONLY if tiles were moved as a result of a key press
        if (moveMade) {
            b.generate(start);
        }

        //write to file if game is over or won, only if in classic mode
        if (start == 2 && write && (gameState.equals("Over") || gameState.equals("Won"))) { 
            writeFile();
            write = false; //make write false so the file is only written to once
            
        }
    }


    public void keyTyped(KeyEvent e) {

    }

    public void keyReleased(KeyEvent e) {

    }

    @Override
    //methods are required as part of MouseListener interface, but are unused
    public void mouseClicked(MouseEvent e) {
        //Get x and y values where mouse is
        int mouseX = e.getX();
        int mouseY = e.getY();
        //Check if click is within bounds of the quit button
        if (mouseX >= 550 && mouseX <= 700 && mouseY >= 650 && mouseY <= 720) {
            gameState = "Over"; //change game state to over

            if (target == 2048) { //write to file - only do it for the Classic Mode
                writeFile();
            }
        }

        //check if user clicks leaderboard button after game is over
        if (gameState.equals("Over")) {
            if (mouseX >= 250 && mouseX <= 550 && mouseY >= 580 && mouseY <= 650) {
                if (secondWindow == null) {
                    secondWindow = new Leaderboard(firstWindow);
                }
                //close the window and display leaderboard
                fifthWindow.setVisible(false);
                this.setVisible(false);
                secondWindow.updateLeaderboard();
                secondWindow.setVisible(true);
                
            }
        }
    }

    /**
     * Method to write name and score to the data file
     */
    public void writeFile() {
        
        try { //try-catch statement to write their name and score to the Players file
            FileWriter fw = new FileWriter("players.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);

            //write the player's name and score to file
            bw.write(playerName + "\n" + score + "\n");

            bw.flush();
            bw.close();
        } catch (IOException e) { //carch IO Exception
            System.out.println("Error");
        }         
    }

    public void mousePressed(MouseEvent e) {

    }

    public void mouseReleased(MouseEvent e) {

    }

    public void mouseEntered(MouseEvent e) {

    }

    public void mouseExited(MouseEvent e) {

    }

}
