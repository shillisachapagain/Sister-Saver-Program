/*
 * Shilisa, Stephan, Morgan
 * 2023-1-8
 * JFrame for the Game screen where the game will be played
 */
package finalproject.sms;

import java.awt.EventQueue;
import javax.swing.JFrame;

public class GameBoardScreen extends JFrame {
    
    private static ModeSelection fourthWindow;
    private static MainMenu firstWindow;
        
    /**
     * Primary constructor
     * @param s - the ModeSelection object 
     */
    public GameBoardScreen(ModeSelection s) {
        fourthWindow = s;
        
        //create the User interface
        initUI();
    }
    
    /**
     * Secondary constructor, accepts a MainMenu
     * @param m - the MainMenu object
     */
    public GameBoardScreen(MainMenu m){
        firstWindow = m;
    }
    
    //create the custom JFrame
    private void initUI() {        
        //set title of the JFrame
        setTitle("2048+");
        //add a custom JPanel to draw on
        add(new BoardDrawingSurface(firstWindow, this));
        //set the size of the window to full screen
        setSize(800, 800);
        //tell the JFrame what to do when closed
        //this is important if our application has multiple windows
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
    
    public static void main(String[] args) {
        //makes sure that GUI updates nicely with the rest of the OS
        EventQueue.invokeLater(() -> {
            JFrame ex = new GameBoardScreen(fourthWindow);
            ex.setVisible(true);
       
            
        });
    }
}
