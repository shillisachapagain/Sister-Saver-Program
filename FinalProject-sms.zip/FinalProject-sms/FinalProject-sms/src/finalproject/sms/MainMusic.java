/**
 * Shillisa, Morgan, Stephan
 * 2023-1-8
 * Represents class to play music
 */
package finalproject.sms;

import java.io.BufferedInputStream;
import java.io.InputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class MainMusic {
        void playMusic()
        {
        try{ //trycatch for the music
            InputStream musicPath = MainMusic.class.getResourceAsStream("finalSong.wav"); //new music file
            
            //add buffer for mark/reset support
            InputStream bufferedIn = new BufferedInputStream(musicPath);
            
            //determine whether music exists or not
            if(musicPath != null){
                AudioInputStream audioInput = AudioSystem.getAudioInputStream(bufferedIn);
                Clip clip = AudioSystem.getClip();
                clip.open(audioInput);
                clip.start();
                clip.loop(Clip.LOOP_CONTINUOUSLY); //make sure it loops
            }else{ //if the file doesn't exist
                JOptionPane.showMessageDialog(null, "Music file not found");
            }
            
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "Music file not found" + ex);
        }
    }
}
